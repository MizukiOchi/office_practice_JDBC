package jp.co.sss.book.servlet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.co.sss.book.bean.BookUser;
import jp.co.sss.book.dao.BookUserDAO;

/**
 * ログイン用サーブレット
 *
 * @author system_shared
 */
@WebServlet(urlPatterns = { "/login" })
public class Login extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            String bookUserId = request.getParameter("bookUserId");
            String password = request.getParameter("password");

            BookUser bookUser = BookUserDAO.findByUserIDAndPassword(bookUserId, password);

            if (bookUser != null) {
                // TODO 下記コードを、書籍一覧表示用のサーブレットにフォワードするように編集してください。
                request.getRequestDispatcher("/select/list.jsp").forward(request, response);
            } else {
                request.setAttribute("errMessage", "ユーザID、またはパスワードが間違っています。");
                request.getRequestDispatcher("/index.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
