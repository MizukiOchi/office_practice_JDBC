package jp.co.sss.book.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * データベースへの接続、切断用クラス
 *
 * @author system_shared
 */
public class DBManager {
    /**
     * データベースに接続
     *
     * @return 接続情報
     */
    public static Connection getConnection() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "book_user",
                    "systemsss");
            return con;
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * データベースとの接続を切断
     *
     * @param con 接続情報
     */
    public static void close(Connection con) {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * データベースとの接続を切断
     *
     * @param ps ステートメント情報
     * @param con 接続情報
     */
    public static void close(PreparedStatement ps, Connection con) {
        if (ps != null) {
            try {
                ps.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
